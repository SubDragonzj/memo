#!/bin/bash

echo "this is for Ubuntu 13.04"

function pause(){
   read -p "$*"
}
pause 'Press [Enter] key to continue... or if you use a another Version of Ubuntu, press CTRL+C'
sudo apt-get install -y gcc ccache

sudo apt-get install -y bison build-essential curl flexg++-multilib gcc-multilib git-core gnupg gperflib32ncurses5-dev lib32readline-gplv2-dev lib32z1-devlibesd0-dev libncurses5-dev libsdl1.2-devlibwxgtk2.8-dev libxml2 libxml2-utils lzopopenjdk-6-jdk openjdk-6-jre pngcrush schedtoolsquashfs-tools xsltproc zip zlib1g-dev python-software-properties
sudo ln -s /usr/lib/i386-linux-gnu/mesa/libGL.so.1 /usr/lib/i386-linux-gnu/libGL.so
sudo add-apt-repository "deb http://ppa.launchpad.net/webupd8team/java/ubuntu raring main"
sudo apt-get update
sudo apt-get install -y oracle-java6-installer
ls -la /etc/alternatives/java* && ls -la /etc/alternatives/jar
java -version
mkdir ~/bin
PATH=~/bin:$PATH
curl http://commondatastorage.googleapis.com/git-repo-downloads/repo > ~/bin/repo && chmod a+x ~/bin/repo

echo "export USE_CCACHE=1" >> .bashrc
source ~/.bashrc
prebuilts/misc/linux-x86/ccache/ccache -M 50G

echo "finished. You can now add your favourite Repo. Have fun"
