$ cd bootimg

$ ./split_bootimg.pl boot.img

$ mkdir ramdisk

$ cd ramdisk

$ gzip -dc ../boot.img-ramdisk.gz | cpio -i



执行完这些命令后在文件夹下会多出一些文件，boot.img-kernel 就是内核，将它重命名为 kernel 并复制到 .mk 指定的目录，ramdisk 文件夹下有一些和我们编译脚本文件夹对应的文件（xxx.rc,xxx.sh 等），复制/merge 过来

recovery.img 解包也是一样的，只需要重命名为 boot.img 就可以了，解出来的 boot.img-kernel 我们不需要，需要 /ramdisk 文件夹下的文件，将编译脚本下对应的文件替换。
